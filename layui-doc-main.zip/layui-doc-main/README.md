
# Layui-doc

#### 介绍
    1、新增模板商城源代码
    2、修复原有bug

### QQ群
![输入图片说明](https://images.gitee.com/uploads/images/2021/0930/000848_5c4c6dc3_9782782.png "屏幕截图.png")

  <a target="_blank" href="https://qm.qq.com/cgi-bin/qm/qr?k=Ud9zOTKW3DDx959_oigK3mdHQQ1Xa4OF&jump_from=webapi"><img border="0" src="//pub.idqqimg.com/wpa/images/group.png" alt="Layui+" title="Layui+"></a>

### 微信群
![输入图片说明](https://images.gitee.com/uploads/images/2021/0930/154243_1576c0a5_9782782.png "屏幕截图.png")


[layui-electron](https://gitee.com/layuiplus/layui-electron) 可生成用layui开发桌面软件
 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0924/234952_8aa07a0b_9782782.png "屏幕截图.png")

## 怀念陪伴一起渡过的时光
2021 年 9 月 24 日 发布官网停止维护后，第一时间整站文档备份，后续会整合一套layui+vue的jquery框架，后续开源.





